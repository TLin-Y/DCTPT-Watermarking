%Add encode-decode feature
%paper: https://ieeexplore.ieee.org/abstract/document/7322663
%Tianlin Yang 40010303
clear;
clc;

%Set transparency ratio of the watermark
alpha=input('Encode transparency alpha of watermarking(1-100) larger stronger = ');
image = imread('lena_color.tiff'); 
OriginalIsize= size(image);
markbefore = imread('redLink.png');
markbefore=imresize(markbefore,[OriginalIsize(1),OriginalIsize(2)]);% up size to original image 
%-------Free select -----------------Use it if needed--------------------
%{ 
disp('Select image to apply watermark��');
[filename2, pathname2] = uigetfile('*.*', 'Load image for watermarking');
pathfile2=fullfile(pathname2, filename2);
image=imread(pathfile2); 
disp('Select watermark��');
[filename, pathname] = uigetfile('*.*', 'Load watermark');
pathfile=fullfile(pathname, filename);
markbefore=imread(pathfile); 
%}

markbefore2=rgb2gray(markbefore);%Put watarmark to Binary(black white condition)
mark=im2bw(markbefore2);
figure(1);

subplot(3,5,1);
a = size(markbefore);
imshow(markbefore),title(['Original watermark size:' num2str(a)]);
a = size(mark);
subplot(3,5,2);    
imshow(mark),title(['Binary watermark size:' num2str(a)]);   

I=mark;
%----------------Key should be randomly generated---------------
%TODO, some of randn is good, some not, need find limitation range of it
%TODO2, direct num-key not good, may try "abcdefg" a=0.1255,b=2.4896 etc..
k1=randn(1,8);  %Random value generate k1,k2
k2=randn(1,8);
%------------For demo, keep k1/k2 stable
k1 = [-0.1255    1.1678   -1.6970   -1.1682   -0.1460    2.4896    0.3280    0.1848];
k2 = [2.1891    0.2804    1.3281    0.8329   -1.7363   -0.0759    2.0774    1.1366];
%------------If i use another key?
%k1 = [2.1891    0.2804    1.3281    0.8329   -1.7363   -0.0759    2.0774    1.1366];
%k2 = [2.1891    0.2804    1.3281    0.8329   -1.7363   -0.0759    2.0774    1.1366];
a = size(image);
subplot(3,5,3),imshow(image,[]),title(['Original image size:' num2str(a)]);
yuv=rgb2ycbcr(image);   %RGB-YCbCr
Y=yuv(:,:,1);    %Gray layer
Cb=yuv(:,:,2);      %Color layer which should add watermark here
Cr=yuv(:,:,3);
[rm2,cm2]=size(Cb);   %Create Matrix with same size of color layer Cb
before=blkproc(Cb,[8 8],'dct2');   %Divide Cb layer as 8��8 block��each block do DCT transfer��record them to 'before'
mark = imresize(mark, [rm2/8 cm2/8]);%1/8tatio, 512/8 = 64 x 64
marksize=size(mark);   %calculate length and width of watermark
rm=marksize(1);      %wm row
cm=marksize(2);     %wm colume

%Watermark applying
after = encodeWatermark(before,mark,k1,k2,alpha);
a = size(after);
subplot(3,5,6),imshow(after,[]),title(['Watermark encoded size:' num2str(a)]);  

%Combine to output RGB.jpg
result=blkproc(after,[8 8],'idct2');    %divede after to 8��8 block��each of them do IDCT
yuv_after=cat(3,Y,result,Cr);      %Combine Y U V 3 layers
rgbOutput=ycbcr2rgb(yuv_after);    %transfer YUV to RGB
imwrite(rgbOutput,'EncodeMarkedResult.jpg','jpg');      %Save watermark
a = size(rgbOutput);
subplot(3,5,4),imshow(rgbOutput,[]),title(['Watermarked image size:' num2str(a)]);  


%figure(1);
withmark = rgbOutput;%Pass input
ExtractedMark = extractDecodeWT(withmark,mark,k1,k2);
a = size(rgbOutput);
subplot(3,5,5);
imshow(ExtractedMark,[]),title(['Extracted watermark size:' num2str(a)]);

%----------------------------- Attacks ----------------------------------
%TODO: need to add more attacks
%TODO2: need to add anti-cropping skills
%Note for TODO2:
%1. reduce key size to (1,4)
%2. can put 2 64x64 watermarks to original image 512x512
%3. randomlize the distribution of key pixels.
%4. if reduce key to size(1,2), could get 4 copys of watermark.
%TODO3: inorder to anti-randomlize cropping
%Use 16x16 or 8x8 tiny watermark, fully disruibuted for all 512x512 range.
%if one survive, anti is good!!
figure(2);
%Add noise attack
result_1=rgbOutput;
noise=80*randn(size(result_1));    %Random value
result_1=double(result_1)+noise;        %add noise
withmark=uint8(result_1);
subplot(4,6,1);
imshow(withmark,[]);
title('Noise image');
withmark=result_1;
ExtractedMark = extractDecodeWT(withmark,mark,k1,k2);
subplot(4,6,2);
imshow(ExtractedMark,[]),title('Noise watermark');

%Cutting attack simulation
result_2=rgbOutput;
A=result_2(:,:,1);
B=result_2(:,:,2);
C=result_2(:,:,3);
A(1:124,1:400)=512;   
B(1:124,1:400)=512;   
C(1:124,1:400)=512; 
result_2=cat(3,A,B,C);
subplot(4,6,3);
imshow(result_2);
title('Croped image');
withmark=result_2;
ExtractedMark = extractDecodeWT(withmark,mark,k1,k2);
subplot(4,6,4);
imshow(ExtractedMark,[]),title('Crop watermark');

%DWT-Compression attack
[cA1,cH1,cV1,cD1]=dwt2(rgbOutput,'Haar');    %DWT transfer
cA1=cpre(cA1); %compression attack
cH1=cpre(cH1);
cV1=cpre(cV1);
cD1=cpre(cD1);
result_3=idwt2(cA1,cH1,cV1,cD1,'Haar');
result_3=uint8(result_3);
subplot(4,6,5);
imshow(result_3);
title('DWT compression');
withmark=result_3;
ExtractedMark = extractDecodeWT(withmark,mark,k1,k2);
subplot(4,6,6);
imshow(ExtractedMark,[]),title('DWT-Compression watermark');


%Down-sampling attack
result_4 = imresize(rgbOutput,0.5);
subplot(4,6,7);
imshow(result_4);
title('Down-sampling 2x');
withmark=result_4;
smark = imresize(mark,0.5);
ExtractedMark = extractDecodeWT(withmark,smark,k1,k2);
subplot(4,6,8);
imshow(ExtractedMark,[]),title('Down-sampling 2x watermark');

%Median-filtering attack
result_5(:,:,1) = medfilt2(rgbOutput(:,:,1));
result_5(:,:,2) = medfilt2(rgbOutput(:,:,2));
result_5(:,:,3) = medfilt2(rgbOutput(:,:,3));
subplot(4,6,9);
imshow(result_5);
title('Median-filter');
withmark5=result_5;
ExtractedMark5 = extractDecodeWT(withmark5,mark,k1,k2);
subplot(4,6,10);
imshow(-ExtractedMark5,[]),title('Median-filter watermark');

%Motion-filtering attack
h = fspecial('motion', 25, 25);
result_6 = imfilter(rgbOutput, h);
subplot(4,6,11);
imshow(result_6);
title('Motion-filter');
withmark6=result_6;
ExtractedMark6 = extractDecodeWT(withmark6,mark,k1,k2);
subplot(4,6,12);
imshow(ExtractedMark6,[]),title('Motion-filter watermark');

%Brightness attack
result_7 = rgbOutput+200;
subplot(4,6,13);
imshow(result_7);
title('Brightness');
withmark=result_7;
ExtractedMark = extractDecodeWT(withmark,mark,k1,k2);
subplot(4,6,14);
imshow(ExtractedMark,[]),title('Brightness watermark');

%Darkness attack
result_8 = rgbOutput-185;
subplot(4,6,15);
imshow(result_8);
title('Darkness');
withmark=result_8;
ExtractedMark = extractDecodeWT(withmark,mark,k1,k2);
subplot(4,6,16);
imshow(ExtractedMark,[]),title('Darkness watermark');

%PS attack
result_9 = imread('EncodeMarkedResultPS.jpg');
subplot(4,6,17);
imshow(result_9);
title('PS');
withmark=result_9;
ExtractedMark = extractDecodeWT(withmark,mark,k1,k2);
subplot(4,6,18);
imshow(ExtractedMark,[]),title('PS watermark');













%-----------------------Functions--------------------------------------

function result=cpre(I)%DWT then compres attack function
thold=80;
A=I(:,:,1);
B=I(:,:,2);
C=I(:,:,3);
[c,k]=size(A);
for i=1:c
    for j=1:k
        if A(i,j)<=thold
            A(i,j)=0;
        end
        if B(i,j)<=thold
            B(i,j)=0;
        end
        if C(i,j)<=thold
            C(i,j)=0;
        end
    end
end
result=cat(3,A,B,C);
end

function [after] = encodeWatermark(before,mark,k1,k2,alpha)
%TODO2: add watermark copy option 'C', 64x64 should from 2-4.
after = before;   %Initilize 'after' watermark
marksize=size(mark);   %calculate length and width of watermark should be 64x64, 512/8
rm=marksize(1);      %wt row
cm=marksize(2);     %wt colume
for i=1:rm          %Adding watermark for each row
    for j=1:cm %than for each colum on that row
        x=(i-1)*8;%First loop opreate on 1,8 2,7 3,6 4,5 5,4 6,3 7,2 8,1 which is diagonal line
        y=(j-1)*8;
        if mark(i,j)==1 %If target pix = black, do it 64x64 times.
            k=k1; %transfer to random value k1 length (1,8)
        else
            k=k2; %white, transfer to random value k2 length (1,8)
        end
        after(x+1,y+8) = before(x+1,y+8) + alpha*k(1);%1 watermark pix need transfer 8 pix with encoded alpha value
        after(x+2,y+7) = before(x+2,y+7) + alpha*k(2);
        after(x+3,y+6) = before(x+3,y+6) + alpha*k(3);
        after(x+4,y+5) = before(x+4,y+5) + alpha*k(4);
        after(x+5,y+4) = before(x+5,y+4) + alpha*k(5);
        after(x+6,y+3) = before(x+6,y+3) + alpha*k(6);
        after(x+7,y+2) = before(x+7,y+2) + alpha*k(7);
        after(x+8,y+1) = before(x+8,y+1) + alpha*k(8);
    end%After 1 loop, go another pix on watermark.
end%The down-sampled 64x64 watermark now back to 512x512 key watermark.
end

function [Extracted] = extractDecodeWT(withmark,mark,k1,k2)
marksize=size(mark);   %calculate length and width of watermark
%Change watermarked image to YCbCr range.
yCbCr=rgb2ycbcr(withmark);   %RGB-YCbCr
y2=yCbCr(:,:,1);    %Gray layer
Cb2=yCbCr(:,:,2);   %Watermarked layer
Cr2=yCbCr(:,:,3);
after_2=blkproc(Cb2,[8,8],'dct2');   %Divide watermarked image to 8x8 block apply dct2 transfer
p=zeros(1,8);        %Initilize matrix for extract watermark
for i=1:marksize(1)
for j=1:marksize(2)
x=(i-1)*8;y=(j-1)*8;
p(1)=after_2(x+1,y+8);         %pix by pix extract watermark
p(2)=after_2(x+2,y+7);
p(3)=after_2(x+3,y+6);
p(4)=after_2(x+4,y+5);
p(5)=after_2(x+5,y+4);
p(6)=after_2(x+6,y+3);
p(7)=after_2(x+7,y+2);
p(8)=after_2(x+8,y+1);
if corr2(p,k1)>corr2(p,k2)  %corr2 used to calculate matrix likehood, more like, more close to 1
Extracted(i,j)=1;              %Compare extract p with k1,k2, decode them to binary infomation 0 and 1.
else
Extracted(i,j)=0;
end
end
end
end





