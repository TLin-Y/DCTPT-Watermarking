%Reimplement of the paper work DCT-LP watermarking
%paper: https://ieeexplore.ieee.org/abstract/document/7322663
%Tianlin Yang 40010303
close all;
clear all;
%Set transparency ratio of the watermark
alpha=input('Transparency of watermarking alpha = ');
%Ask user input the Quality Factor
q=input('Quality Factor q = ');

%Import images
imtarget = double(imread('LenaGray.bmp'));
imwatermark = double(imread('WaterMarkSreenshotpic.bmp'));

OriginalIsize= size(imtarget);
imwatermark=imresize(imwatermark,[OriginalIsize(1),OriginalIsize(2)]);% up size to original image 
%Plot our inputs

figure(1);
subplot(1,4,1),
imshow(imtarget,[]);
title 'Input image';
subplot(1,4,2),
imshow(imwatermark,[]);
title 'Watermark image';

%Apply Basic DCT2 process for inputs
imTrans = dct2(imtarget);%Trans our input image
wtTrans = dct2(imwatermark);%Trans watermark image
CombineIM=imTrans+alpha*wtTrans;%Combine watermark and input image
%plot the combined output image
OutputI=idct2(CombineIM);
subplot(1,4,3),
imshow(OutputI,[]);
title 'DCT-Watermarked output image';

%Use quality factor generate output image.
imwrite(uint8(OutputI),'WatermarkedOutput.jpg','jpg','quality',q);
compr=imread('WatermarkedOutput.jpg');%read output.jpg as our comparation img
%Extract the watermark
EWTimage=DCTExtract(compr,imtarget,alpha);
subplot(1,4,4),
imshow(EWTimage,[]); 
title 'Extract watermark image';
%Get the reference score to make comparations
imtarget=imwatermark;
imwatermark=EWTimage;
% Root mean square error
[m,n] = size(imtarget);%get the size of input image m,n
RMSE = sqrt(sum((imtarget(:)-imwatermark(:)).^2)/(m*n));
% Peak signal to noise Ratio
L = 255;% uint8 should be 255
PSNR = 10*log10(L^2/RMSE);
fprintf('\n The PSNR is %0.4f\n', PSNR);

%----------Functions library-----------
function[EWTimage] = DCTExtract(CombineIM,Original,alpha)
CombineIM = double(CombineIM);
Original = double(Original); 
IM = dct2(CombineIM);%DCT to water marked image
IM2 = dct2(Original);%DCT to original image
EWTimage=(IM-IM2)./alpha;
%Extract the watermark
EWTimage = idct2(EWTimage);
end

