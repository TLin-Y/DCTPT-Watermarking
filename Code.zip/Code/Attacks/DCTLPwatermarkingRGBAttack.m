%Reimplement of the paper work DCT+LP watermarking
%paper: https://ieeexplore.ieee.org/abstract/document/7322663
%Tianlin Yang 40010303
close all;
clear all;
%Set transparency ratio of the watermark
alpha=input('Transparency of watermarking alpha(defualt=0.01): ');
if isempty(alpha)
     alpha = 0.01;
end
q=100;
%Pyramid layers
k=2;

%Import images
imInput = imread('lena_color.bmp');
imwatermark = imread('test.png');

%Attak input
inimMarked=imInput;
inimCrop = imInput;
inimDraw = imInput;
inimRot = imread('lena_colorRotate90.bmp');
inimRot2 = imread('lena_colorRotate180.bmp');
inimFlip = imread('lena_colorFlip.bmp');
inimColor = imread('lena_colorColor.bmp');
inimDark = imread('lena_colorDark.bmp');

%Use quality factor generate output image.
imMarked=imread('LenaPhoto.jpg');%read output.jpg as our comparation img
imCrop = imread('WatermarkedOutputCrop.jpg');
imDraw = imread('WatermarkedOutputDraw2.jpg');
imRot = imread('WatermarkedOutputRotate90.jpg');
imRot2 = imread('WatermarkedOutputRotate180.jpg');
imFlip = imread('WatermarkedOutputFlip.jpg');
imColor = imread('WatermarkedOutputColor.jpg');
imDark = imread('WatermarkedOutputDark.jpg');

%Extract the watermark
figure;
alpha2 = alpha;
ExtractWT = DCTPTExtract(imMarked,imInput,alpha2,k);%extracting watermark
subplot(4,5,1),
imshow(imMarked,[]); 
title 'Camera attack';
subplot(4,5,6),
imshow(ExtractWT,[]); 
title 'Camera attack WT';

ExtractWTcrop = DCTPTExtract(imCrop,inimCrop,alpha2,k);%extracting watermark
subplot(4,5,2),
imshow(imCrop,[]); 
title 'Crop attack';
subplot(4,5,7),
imshow(ExtractWTcrop,[]); 
title 'Crop attack WT';

ExtractWTDraw = DCTPTExtract(imDraw,inimDraw,alpha2,k);%extracting watermark
subplot(4,5,3),
imshow(imDraw,[]); 
title 'Draw attack ';
subplot(4,5,8),
imshow(ExtractWTDraw,[]); 
title 'Draw attack WT';

ExtractWTflip = DCTPTExtract(imFlip,inimFlip,alpha2,k);%extracting watermark
subplot(4,5,4),
imshow(imFlip,[]); 
title 'Flip attack';
subplot(4,5,9),
imshow(ExtractWTflip,[]); 
title 'Flip attack WT';

ExtractWTrot = DCTPTExtract(imRot,inimRot,alpha2,k);%extracting watermark
subplot(4,5,5),
imshow(imRot,[]); 
title 'Rot90 attack';
subplot(4,5,10),
imshow(ExtractWTrot,[]); 
title 'Rot90 attack WT';

ExtractWTrot2 = DCTPTExtract(imRot2,inimRot2,alpha2,k);%extracting watermark
subplot(4,5,11),
imshow(imRot2,[]); 
title 'Rot180 attack';
subplot(4,5,16),
imshow(ExtractWTrot2,[]); 
title 'Rot180 attack WT';

ExtractWTColor = DCTPTExtract(imColor,inimColor,alpha2,k);%extracting watermark
subplot(4,5,12),
imshow(imColor,[]); 
title 'Color  attack';
subplot(4,5,17),
imshow(ExtractWTColor,[]); 
title 'Color attack WT';

ExtractWTDark = DCTPTExtract(imDark,inimDark,alpha2,k);%extracting watermark
subplot(4,5,13),
imshow(imDark,[]); 
title 'Dark attack';
subplot(4,5,18),
imshow(ExtractWTDark,[]); 
title 'Dark attack WT';

%Print out all of PSNR
fprintf('\n The Camera attack PSNR is %0.4f\n', CPSNR(imwatermark,imInput));
fprintf('\n The Crop attack PSNR is %0.4f\n', CPSNR(imwatermark,inimCrop));
fprintf('\n The Draw attack PSNR is %0.4f\n', CPSNR(imwatermark,inimDraw));
fprintf('\n The Flip attack PSNR is %0.4f\n', CPSNR(imwatermark,inimFlip));
fprintf('\n The Rot90 attack PSNR is %0.4f\n', CPSNR(imwatermark,inimRot));
fprintf('\n The Rot180 attack PSNR is %0.4f\n', CPSNR(imwatermark,inimRot2));
fprintf('\n The Color attack PSNR is %0.4f\n', CPSNR(imwatermark,inimColor));
fprintf('\n The Dark attack PSNR is %0.4f\n', CPSNR(imwatermark,inimDark));

function [PSNR] = CPSNR(OriginalWT,ExtractWT)
% Root mean square error
[m,n] = size(OriginalWT);%get the size of input image m,n
RMSE = sqrt(sum((double(OriginalWT(:))-double(ExtractWT(:))).^2)/(m*n));
%fprintf('\n The RMSE is %0.4f\n', RMSE);

% Peak signal to noise Ratio
L = 255;% uint8 should be 255
PSNR = 10*log10(L^2/RMSE);

end

%----------Functions library-----------
%RGB
function out=rgbdct2(img)
[r c p]=size(img);

if(p==3)
    out(:,:,1)=dct2(img(:,:,1));
    out(:,:,2)=dct2(img(:,:,2));
    out(:,:,3)=dct2(img(:,:,3));
else
    out=dct2(img);
end
end

function rec=rgbidct2(img,m,n)
[r c p]=size(img);

if(p==3)
    rec(:,:,1)=idct2(img(:,:,1),[m n]);
    rec(:,:,2)=idct2(img(:,:,2),[m n]);
    rec(:,:,3)=idct2(img(:,:,3),[m n]);
else
    rec=idct2(img);
end
end


function rec=rgbidct2d(img)
[r c p]=size(img);

if(p==3)
    rec(:,:,1)=idct2(img(:,:,1));
    rec(:,:,2)=idct2(img(:,:,2));
    rec(:,:,3)=idct2(img(:,:,3));
else
    rec=idct2(img);
end
end


function[EWTimage] = DCTPTExtract(CombineIM,Original,alpha,k)
CombineIM = double(CombineIM);
Original = double(Original);
for i = 1:k    
    IM = reduce2d(CombineIM);%down-sampling CombineIM with Gaussian pyramid
    Idf{i} = CombineIM - expand2d(IM);%Laplacian pyramid for input image
    CombineIM = IM;% Now update to InputIM
    
    IM = reduce2d(Original);%down-sampling Original with Gaussian pyramid
    Idf2{i} = Original - expand2d(IM);%Laplacian pyramid for input image
    Original = IM;% Now update to watermark
end    
EWTimage=(CombineIM-Original)./alpha;
for i=k:-1:1
EWTimage = expand2d(EWTimage);%add combinedWatermark image loss here
end




end

%Up sampling(decomprass)
function[Ie] = expand2d(I)
mn = size(I)*2;%size up 2x
mn(:,[1,2]);
IDCT = rgbdct2(I);%DCT
Ie = rgbidct2(IDCT,mn(1),mn(2));%IDCT
end

%Down sampling(comprass)
function[Id] = reduce2d(I)
mn = size(I)/2;%size down 2x
mn(:,[1,2]);
IDCT = rgbdct2(I);%DCT
Id = round(rgbidct2d(IDCT(1:mn(1),1:mn(2),:)));%IDCT
end




%-----------------------------------
%{
%percentage fit error (PFE)
PFE = 100*norm(imtarget(:)-imwatermark(:))/norm(imtarget(:));
fprintf('\n The PFE is %0.4f\n', PFE);
% mean absolute error (MAE)
MAE = sum(sqrt((imtarget(:)-imwatermark(:)).^2))/(m*n);
fprintf('\n The MAE is %0.4f\n', MAE);
% defference entropy H
dent = abs(entropy(imtarget)-entropy(imwatermark));
fprintf('\n The defference entropy is %0.4f\n', dent);
% Correlation (CORR)
Rtf = sum(sum(imtarget.*imwatermark));
Rt = sum(sum(imtarget.*imtarget));
Rf = sum(sum(imwatermark.*imwatermark));
CORR = 2*Rtf/(Rt+Rf);
fprintf('\n The CORR is %0.4f\n', CORR);
% signal to noise ration (SNR)
st = mean(mean((double(imtarget)).^2));
ntf =  mean(mean((double(imtarget-imwatermark)).^2));
SNR = 10*log10(st/ntf);
fprintf('\n The SNR is %0.4f\n', SNR);
%}
