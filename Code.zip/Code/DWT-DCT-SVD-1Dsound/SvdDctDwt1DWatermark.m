%Add 2D-1D features
%Tianlin Yang 40010303
%Load original sound
[audio,fs]=audioread('OriginalSound.wav'); 
A=audio(1:160000);%length, when change file, need redid
AL=length(A);%Get length
%Drawing the original sound�� 
subplot(312);plot(A); 
title('Original Sound'); 

%Watermarking photo
I=imread('Watermark.png');
I=im2bw(I);
subplot(311);imshow(I); 
title('Watermarking image');
[m,n]=size(I);
%Reduce 2D to 1D of watermark
piexnum=1;
for i=1:m
    for j=1:n
        w(piexnum,1)=I(i,j);
        piexnum=piexnum+1;
    end
end
wl=size(w);

%Get distribute of 1D sound signal��  
[cOri,lOri]=wavedec(A,2,'haar');     
%Get the low-frequency(Higher energy) and high-freq(lower energy)�� 
Orica2=appcoef(cOri,lOri,'haar',2); 
Oricd2=detcoef(cOri,lOri,2); 
Oricd1=detcoef(cOri,lOri,1); 
Orica2L=length(Orica2); 

%DCT Transfor
Orica2DCT=dct(Orica2);
%Divided to piece by piece
knum=wl(1);   %Num of pieces
PieceL=Orica2L/knum;  %ca2 every piece length
j=1;
delta=0.5;
%Add watermark in to sound piece by piece
for i=1:knum
    ca22=Orica2DCT(j:j+PieceL-1);
    Y=ca22(1:PieceL/4);        %Extract front 1/4 ratio
    Y=reshape(Y,10,10);
    
    [U,S,V]=svd(Y);        %SVD transfer
    S1=S(1,1);
    S2=S(2,2);
    D=floor(S1/(S2*delta)); %Judgement eq
    %Depend on D is odd or even:
    if(mod(D,2)==0)
        if (w(i)==1)                                       
            S(1,1)=S(2,2)*delta*(D+1);  
        else   
            S(1,1)=S(2,2)*delta*D;  
        end  
    else                                   
        if (w(i)==1)  
            S(1,1)=S(2,2)*delta*D; 
        else  
            S(1,1)=S(2,2)*delta*(D+1);  
        end  
    end  
    Y11=U*S*V';              %SVD inverse 
    Y1=reshape(Y11,100,1);
    ca22(1:100)=Y1(1:100);
    ca2DCTnew(j:j+PieceL-1)=ca22;%Replace watermarked 1/4 ratio to original 1/4 ratio
    j=j+PieceL;
end
%IDCT
ca2new=idct(ca2DCTnew');
%IDWT
c1=[ca2new',Oricd2',Oricd1'];
Anew=waverec(c1',lOri,'haar');
audiowrite('WaterMarked.wav',Anew,fs); %Save sound
subplot(313);plot(Anew);       %Display the output
title('Watermarked sound')