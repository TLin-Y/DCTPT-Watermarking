%Add 2D-1D features
%Tianlin Yang 40010303
figure(2);
%Load original picture
I=imread('Watermark.png');
I=im2bw(I);
%Load original sound
audio = audioread('OriginalSound.wav'); 
A=audio(1:160000);
%Load watermarked sound
[A1,fs]=audioread('WaterMarked.wav'); 
AL=length(A1);
%Draw sound�� 
subplot(211);plot(A1); 
axis([0,160000,-1,1]);
title('watermark sound signal');

[c,l]=wavedec(A1,2,'haar');      
ca2=appcoef(c,l,'haar',2); 
cd2=detcoef(c,l,2);
cd1=detcoef(c,l,1); 
ca2L=length(ca2); 
ca2DCT=dct(ca2);
k=100; 
DL=ca2L/k;
j=1;
delta=0.5;
for i=1:k
    ca22=ca2DCT(j:j+DL-1);
    Y=ca22(1:DL/4);         
    Y=reshape(Y,10,10);
    
    [U,S,V]=svd(Y);       
    S1=S(1,1);
    S2=S(2,2);
    D=round(S1/(S2*delta)); 
    if(mod(D,2)==0)
        water(i)=0;
    else                                      
        water(i)=1;
    end  
    j=j+DL;
end
for i=1:10
    for j=1:10
        p=j+10*(i-1);
        J(i,j)=water(p);
    end
end
subplot(212);imshow(J);
title('Extracted watermark');
imwrite(J,'Extracted watermark.png');
