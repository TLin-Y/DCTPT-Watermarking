%Reimplement of the paper work DCT+LP watermarking
%paper: https://ieeexplore.ieee.org/abstract/document/7322663
%Tianlin Yang 40010303
close all;
clear all;
%Set transparency ratio of the watermark
alpha=input('Transparency of watermarking alpha = ');
%Ask user input the Quality Factor
q=input('Quality Factor q = ');
%Pyramid layers--------------------------------------------User control!
k=6;



%Import images
imInput = double(imread('LenaGray.bmp'));
imwatermark = double(imread('WaterMarkSreenshotpic.bmp'));

OriginalIsize= size(imInput);
imwatermark=imresize(imwatermark,[OriginalIsize(1),OriginalIsize(2)]);% up size to original image 

%Plot our inputs
figure(1);
subplot(1,4,1),
imshow(imInput,[]);
title 'Input image';
subplot(1,4,2),
imshow(imwatermark,[]);
title 'Watermark image';

%Apply Basic DCT2 process for inputs
[CombineIM,imTrans,wtTrans] = DCTPT(imInput,imwatermark,alpha,k);%Trans our input image

%plot the combined output image
OutputI=CombineIM;
subplot(1,4,3),
imshow(OutputI,[]);
title 'DCTLP-Watermarked output image';


%Use quality factor generate output image.
imwrite(uint8(OutputI),'WatermarkedOutput.jpg','jpg','quality',q);
imMarked=imread('WatermarkedOutput.jpg');%read output.jpg as our comparation img

%Extract the watermark
alpha2 = alpha;
ExtractWT = DCTPTExtract(imMarked,imInput,alpha2,k);%extracting watermark
subplot(1,4,4),
imshow(ExtractWT,[]); 
title 'Extract watermark image';

%Spectrums
%{
FA=fft2(imInput);
figure(2);
imshow(FA);title('spectrum of original image');
FB=fft2(imMarked);
figure(3);
figure,imshow(FB); title('spectrum of watermarked image');
%}

%Get the reference score to make comparations
OriginalWT=imwatermark;%Original watermark
ExtractWT=double(ExtractWT);%Extract watermark

% Root mean square error
[m,n] = size(OriginalWT);%get the size of input image m,n
RMSE = sqrt(sum((OriginalWT(:)-ExtractWT(:)).^2)/(m*n));
%fprintf('\n The RMSE is %0.4f\n', RMSE);

% Peak signal to noise Ratio
L = 255;% uint8 should be 255
PSNR = 10*log10(L^2/RMSE);
fprintf('\n The PSNR is %0.4f\n', PSNR);


%show original pyramid
figure;
for i=1:k
    %figure(5+i);
    subplot(3,k,i)
    imshow(imTrans{i},[]);%laplacian images
    title (['Layer ',num2str(i)])
end

%show watermark pyramid
for i=1:k
    %figure(5+i);
    subplot(3,k,i+k)
    imshow(wtTrans{i},[]);%laplacian images
    title (['Layer ',num2str(i)])
end



%----------Functions library-----------


%DCT-PT
function[imf,Idf,Idf2] = DCTPT(InputIM,IMwaterMark,alpha1,k)
%Image down-sampling
for i = 1:k    
    IM = reduce2d(InputIM);%down-sampling inputIM with Gaussian pyramid
    Id1 = InputIM - expand2d(IM);
    Idf{i} = Id1;%Laplacian pyramid loss for input image
    InputIM = IM;% Now update to InputIM
    
    IM = reduce2d(IMwaterMark);%down-sampling watermark with Gaussian pyramid
    Id2 = IMwaterMark - expand2d(IM);%Laplacian pyramid loss for input image
    Idf2{i} = Id2;
    IMwaterMark = IM;% Now update to watermark  
    Idf{i} = Id1+alpha1*Id2;
end   
imw=InputIM+alpha1*IMwaterMark;%Combine them 
%Image reconstruction
imf = imw;
for i=k:-1:1
    %Loss added:Idf{i}+alpha1*Idf2{i}-----------------------User Control!,
%If need lower level of compression result, need delete add loss part.
%Can delete seprately, try to get differ recovery part.
    imf = Idf{i}+ expand2d(imf);% add loss back, also add alpha for watermark loss.
end

end

function[EWTimage] = DCTPTExtract(CombineIM,Original,alpha,k)

CombineIM = double(CombineIM);
Original = double(Original);  
    IM = reduce2d(CombineIM);%down-sampling CombineIM with Gaussian pyramid
    CombineIM = IM;% Now update to InputIM
    IM = reduce2d(Original);%down-sampling Original with Gaussian pyramid
    Original = IM;% Now update to watermark

EWTimage=(CombineIM-Original)./alpha;
EWTimage = expand2d(EWTimage);

end

%Up sampling(decomprass)
function[Ie] = expand2d(I)
Rs = 2;
mn = size(I)*Rs;%size up 2x
IDCT = dct2(I);%DCT
Ie = idct2(IDCT,[mn(1) mn(2)]);%IDCT
end

%Down sampling(comprass)
function[Id] = reduce2d(I)
Rs = 2;
mn = size(I)/Rs;%size down 2x
IDCT = dct2(I);%DCT
Id = round(idct2(IDCT(1:mn(1),1:mn(2))));%IDCT
end




%-----------------Other basic parameters if needed------------------
%{
%percentage fit error (PFE)
PFE = 100*norm(imtarget(:)-imwatermark(:))/norm(imtarget(:));
fprintf('\n The PFE is %0.4f\n', PFE);
% mean absolute error (MAE)
MAE = sum(sqrt((imtarget(:)-imwatermark(:)).^2))/(m*n);
fprintf('\n The MAE is %0.4f\n', MAE);
% defference entropy H
dent = abs(entropy(imtarget)-entropy(imwatermark));
fprintf('\n The defference entropy is %0.4f\n', dent);
% Correlation (CORR)
Rtf = sum(sum(imtarget.*imwatermark));
Rt = sum(sum(imtarget.*imtarget));
Rf = sum(sum(imwatermark.*imwatermark));
CORR = 2*Rtf/(Rt+Rf);
fprintf('\n The CORR is %0.4f\n', CORR);
% signal to noise ration (SNR)
st = mean(mean((double(imtarget)).^2));
ntf =  mean(mean((double(imtarget-imwatermark)).^2));
SNR = 10*log10(st/ntf);
fprintf('\n The SNR is %0.4f\n', SNR);
%}
